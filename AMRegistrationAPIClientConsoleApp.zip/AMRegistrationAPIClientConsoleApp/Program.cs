﻿using Microsoft.Identity.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace AMRegistrationAPIClientConsoleApp
{
    class Program
    {

        static string CSVURL = "https://fnamreportsapidev.aseqa.worldbank.org/api/regdata/CSV";
        static string JSONURL = "https://fnamreportsapidev.aseqa.worldbank.org/api/regdata/JSON";
        static string APIMURL = "https://amreportsapidev.worldbank.org/api/regdata/JSON";
        static void Main(string[] args)
        {
            string json = RunAsync().GetAwaiter().GetResult();

            //if json, deserialize
            //var result = JsonConvert.DeserializeObject(json);


            Console.WriteLine("Result from the API is:");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine(json);
            Console.Read();
        }


        private static async Task<string> RunAsync()
        {
            //AuthenticationConfig config = AuthenticationConfig.ReadFromJsonFile("appsettings.json");
            AuthenticationConfig config = new AuthenticationConfig();
            // You can run this sample using ClientSecret or Certificate. The code will differ only when instantiating the IConfidentialClientApplication
            bool isUsingClientSecret = true;

            // Even if this is a console application here, a daemon application is a confidential client application
            IConfidentialClientApplication app = null;

            if (isUsingClientSecret)
            {
                app = ConfidentialClientApplicationBuilder.Create(config.ClientId)
                    .WithClientSecret(config.ClientSecret)
                    .WithAuthority(new Uri(config.Authority))
                    .Build();
            }

            //else
            //{
            //    X509Certificate2 certificate = ReadCertificate(config.CertificateName);
            //    app = ConfidentialClientApplicationBuilder.Create(config.ClientId)
            //        .WithCertificate(certificate)
            //        .WithAuthority(new Uri(config.Authority))
            //        .Build();
            //}

            // With client credentials flows the scopes is ALWAYS of the shape "resource/.default", as the 
            // application permissions need to be set statically (in the portal or by PowerShell), and then granted by
            // a tenant administrator
            string[] scopes = new string[] { config.TodoListScope };

            AuthenticationResult result = null;
            try
            {
                result = await app.AcquireTokenForClient(scopes)
                    .ExecuteAsync();
                Console.WriteLine("Token acquired \n");
            }
            catch (MsalUiRequiredException ex)
            {
                // The application doesn't have sufficient permissions.
                // - Did you declare enough app permissions during app creation?
                // - Did the tenant admin grant permissions to the application?
                Console.WriteLine(ex.Message);
            }
            catch (MsalServiceException ex) when (ex.Message.Contains("AADSTS70011"))
            {
                // Invalid scope. The scope has to be of the form "https://resourceurl/.default"
                // Mitigation: change the scope to be as expected
                Console.WriteLine("Scope provided is not supported");
            }
            
            if (result != null)
            {
                Console.WriteLine("Calling API...");
                var httpClient = new HttpClient();
                var apiCaller = new ProtectedApiCallHelper(httpClient);
                return await apiCaller.CallWebApiAndProcessResultASync(APIMURL, result.AccessToken);
            }

            return null;
        }

    }
}
