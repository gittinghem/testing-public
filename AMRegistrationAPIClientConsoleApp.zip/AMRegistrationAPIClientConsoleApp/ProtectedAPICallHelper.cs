﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace AMRegistrationAPIClientConsoleApp
{
    public class ProtectedApiCallHelper
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="httpClient">HttpClient used to call the protected API</param>
        public ProtectedApiCallHelper(HttpClient httpClient)
        {
            HttpClient = httpClient;
        }

        protected HttpClient HttpClient { get; private set; }


        /// <summary>
        /// Calls the protected Web API and processes the result
        /// </summary>
        /// <param name="webApiUrl">Url of the Web API to call (supposed to return Json)</param>
        /// <param name="accessToken">Access token used as a bearer security token to call the Web API</param>
        /// <param name="processResult">Callback used to process the result of the call to the Web API</param>
        public async Task<string> CallWebApiAndProcessResultASync(string webApiUrl, string accessToken)
        {
            string json = null;
            if (!string.IsNullOrEmpty(accessToken))
            {
                var defaultRequestHeaders = HttpClient.DefaultRequestHeaders;
                if (defaultRequestHeaders.Accept == null || !defaultRequestHeaders.Accept.Any(m => m.MediaType == "application/json"))
                {
                    HttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                }
                defaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", accessToken);

                HttpResponseMessage response = await HttpClient.PostAsync(webApiUrl, null);
                Console.WriteLine($"response.IsSuccessStatusCode is {response.IsSuccessStatusCode}, response.StatusCode is {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    json = await response.Content.ReadAsStringAsync();
                    var deserializedString = JsonConvert.DeserializeObject(json);
                    var result = JsonConvert.DeserializeObject<IEnumerable<RegistrationObject>>(deserializedString.ToString());
                }
                else
                {
                    Console.WriteLine($"Failed to call the Web Api: {response.StatusCode}");
                    string content = await response.Content.ReadAsStringAsync();

                    // Note that if you got reponse.Code == 403 and reponse.content.code == "Authorization_RequestDenied"
                    // this is because the tenant admin as not granted consent for the application to call the Web API
                    Console.WriteLine($"Content: {content}");
                }
            }

            return json;
        }
    }
}


public class RegistrationObject
{
    [JsonProperty("category")]
    public string Category;
    [JsonProperty("regCode")]
    public string RegCode;
    [JsonProperty("firstName")]
    public string FirstName;
    [JsonProperty("lastName")]
    public string LastName;
    [JsonProperty("institution")]
    public string Institution;
    [JsonProperty("email")]
    public string Email;
    [JsonProperty("regDateModified")]
    public string RegDateModified;
    [JsonProperty("showOnDelegationList")]
    public string ShowOnDelegationList;
}